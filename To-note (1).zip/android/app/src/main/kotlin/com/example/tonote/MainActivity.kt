package com.example.tonote

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
