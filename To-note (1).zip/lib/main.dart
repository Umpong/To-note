import 'package:flutter/material.dart';
import 'screens/login_page.dart';

void main() {
  runApp(const ToNoteApp());
}

class ToNoteApp extends StatelessWidget {
  const ToNoteApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'To-Note',
      theme: ThemeData(fontFamily: 'Roboto'),
      home: const LoginPage(),
    );
  }
}
