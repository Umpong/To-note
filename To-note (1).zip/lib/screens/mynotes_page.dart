import 'dart:math';
import 'package:flutter/material.dart';

class MyNotesPage extends StatefulWidget {
  const MyNotesPage({super.key});

  @override
  State<MyNotesPage> createState() => _MyNotesPageState();
}

class _MyNotesPageState extends State<MyNotesPage> {
  final List<Map<String, dynamic>> notes = [];
  final Random rnd = Random();
  int? selectedIndex;

  Color randomColor() {
    final colors = [
      Colors.tealAccent.shade200,
      Colors.amber.shade300,
      Colors.redAccent.shade100,
      Colors.lightBlue.shade300,
      Colors.white,
    ];
    return colors[rnd.nextInt(colors.length)];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('MyNotes'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: selectedIndex == null
                ? null
                : () {
                    setState(() {
                      notes.removeAt(selectedIndex!);
                      selectedIndex = null;
                    });
                  },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() {
            notes.add({
              'text': '',
              'color': randomColor(),
            });
            selectedIndex = null;
          });
        },
        child: const Icon(Icons.add),
      ),
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/speech.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: notes.length,
          itemBuilder: (context, i) {
            final n = notes[i];
            final isSelected = selectedIndex == i;

            return GestureDetector(
              onTap: () {
                setState(() => selectedIndex = i);
              },
              child: Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  color: n['color'],
                  borderRadius: BorderRadius.circular(14),
                  border: isSelected
                      ? Border.all(color: Colors.black, width: 2)
                      : null,
                ),
                child: TextField(
                  onChanged: (v) => n['text'] = v,
                  decoration: const InputDecoration(
                    hintText: 'Type here...',
                    border: InputBorder.none,
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
