import 'package:flutter/material.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool notifications = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: ListView(
        children: [
          SwitchListTile(
            title: const Text('Enable Notifications'),
            value: notifications,
            onChanged: (v) => setState(() => notifications = v),
          ),
          const ListTile(
            title: Text('About'),
            subtitle: Text('To-Note – Offline Flutter App'),
          ),
        ],
      ),
    );
  }
}
