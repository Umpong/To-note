import 'package:flutter/material.dart';

/// Creates a smooth slide transition between pages
Route slideRoute(Widget page, {bool reverse = false}) {
  return PageRouteBuilder(
    transitionDuration: const Duration(milliseconds: 500),
    reverseTransitionDuration: const Duration(milliseconds: 500),
    pageBuilder: (_, __, ___) => page,
    transitionsBuilder: (_, animation, __, child) {
      final begin = Offset(reverse ? -1 : 1, 0);
      return SlideTransition(
        position: animation.drive(
          Tween(begin: begin, end: Offset.zero)
              .chain(CurveTween(curve: Curves.easeInOut)),
        ),
        child: child,
      );
    },
  );
}
